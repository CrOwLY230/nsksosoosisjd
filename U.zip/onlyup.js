const {VK, Keyboard} = require('vk-io');
const vk = new VK();
const {updates} = vk; ///https://vk.com/off_bots
const fs = require("fs"); /////////////////////////////// https://vk.com/off_bots
const admins = [518665607]; //// id админа (для логов)
const vip = [232357251]; /////// id админа (для логов)
const acc = require("./base/acc.json");
const uid = require("./base/uid.json");
const rep = require("./base/rep.json");  
setInterval(function(){
	fs.writeFileSync("./base/rep.json", JSON.stringify(rep, null, "\t"))    
}, 1500);
const log = require("./base/log.json");
const config = require("./setting/config.json") 


vk.setOptions({
    token: '542818cec9e992ec1fe6002f94f7e68e0d1eb2f5c6d066cdead00fd7dead1cba47d7bbd301dc1e41693ba', // токен группы
    apiMode: 'parallel',
	pollingGroupId: 185352385 // 1111 замени на id группы 
}); 

vk.updates.use(async (message, next) => {  
    message.user = message.senderId;
    message.text = message.payload.text;  

    if (!message.text) return;
 
    if(!uid[message.user]){
	 	acc.number += 1;
		let numm = acc.number;
		uid[message.user] = {
			id: numm
		}
	
	

    if(message.is("message") && message.isOutbox)
        return; 

 		let id = user_id(message.user); 
 		 
		message.send(` Привет друг, я вижу ты новенький! Напиши «помощь» и узнай, что я могу! `)
	 	   
		
		acc.users[numm] = {
			balance: 4000,
			level: 0,
               podpis: 0,
               hei: 0,
               video: 0,
               kanal: false,
               knser: false,
               mikro: false,
               serkn: false,
               kakake: false,
               uggg: false,
               fggg: false,
               xxxkn: false,
               herkn: false,
               huikn: false,
               govkn: false,
               gerkn: false,
               gggkn: false,
               zolkn: false,
               brilkn: false,
               monit: false,
               prosm: 0,
               dizlike: 0,
               kom: 0,
               huih: 0,
               cers: 0,
               bbbb: 0,
               monk: false,
			podarki: 10,
               kaki: false,
			cip: 0,
			his: 0,
			like: 0,
               obor: false,
			bloks: { 
				cases: false,
                    stream: false,
                    bcases: false,
                    orcase: false,
                    hercase: false,
                    streams: false,
                    vid: false,
                    han: false,
                    gse: false,
                    rrse: false,
                    gras: false,
                    pose: false,
                    bcase: false,
                    gagi: false,
				rukus: false,
				nik: false,
				vivi: false,
                    hersd: false,
                    tata: false,
				bonus: false,
			},
			number: numm,
			id: message.user,
			nick: true,
               name: `Имя буд канала`,
			game: {
				monetka: 0
			},
			msg: { 
				messages: 0, 
				last_msg: "" 
			},
			bank: 0,
			tag: "Новичок", 
			ainfo: {
				vig: 0,
			}, 
			rep: {
				status: false,
				id: false
			},
			ainfo: {
				all_ans: 0,
				ans: 0, 
				good_ans: 0,
				bad_ans: 0,
				vig: 0
			}, 
			ban: false, 
			mute: false,
			warn: 0,
			warn_p: [],
			credit: 0,
			procent: 0,
			job: { 
				name: false, 
				lvl: 0, 
				stop: false, 
				count: 0 
			}, 
			global_podpis: 0,
			prefix: `Игрок #${numm}`,
			rtime: `${time()} | ${data()}` 
			} 
			
		////////////////////  
			vk.api.call('users.get', {
				user_ids: message.user,
				fields: "photo_max,city,verified,status,domain,photo_id,sex,last_seen"
			}).then(res => {
				let user = res[0]; 
				acc.users[user_id(message.user)].prefix = ` ${user.first_name} `;
			}).catch((error) => {console.log('err[prefix]'); }); 
	}
	let id = user_id(message.user);

 


	if(message.text){ 
	let user = acc.users[user_id(message.user)];
		acc.msg += 1;
		if(!acc.users[user_id(message.user)]) return;
		acc.users[id].msg.messages += 1;
		acc.users[id].msg.last_msg = `${time()} | ${data()}`; 
		if(acc.users[id].mute == true) return; 
	}
	
	if(acc.users[id].ban != false) return message.send(``); 

    try {
        await next();
    } catch (err) { console.error(err) }
});

 

 	vk.updates.hear(/^(?:тайм)/i,  (message) => { 
 		return message.send(`&#10004; » Работаю!\n⏰ » Дней: ${uptime.days}\n⏰ » Часов: ${uptime.hours}\n⏰ » Минут: ${uptime.min}\n⏰ » Секунд: ${uptime.sec}`);
 	});	

	vk.updates.hear(/^(?:1|1)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)];
	if(user.balance == null) return message.send(`⚠ Произошла ошибка ! Пожалуйста, сообщите в репорт.`);
	return message.send(`
	@id${message.user} (${user.prefix}), ❄ Прежде чем стать блогером, тебе нужно будет подкопить деньжат используя команду «Работать», ее ты можешь использовать раз в 10 минут.

⭕Далее, тебе нужно будет приобрести оборудование для съемки командой «Оборудование», после этого, можешь создавать канал - создать «Название».

❗Помни, что нецензурная лексика в названии канала может привести к бану, после создания канала, снимай ролики - снять «название» и набирай популярность.

👾Напиши команду "ринфо" без кавычек, там ты сможешь приглашать друзей и зарабатывать деньги. А так же узнать сколько друзей ты пригласил!

✅Полный список команд ты можешь получить введя «Команды».


😋Удачи!.

Платформа: @off_bots (OFF-BOT.RU | Боты ВК — и другое.) 
    `)
   });

vk.updates.hear(/^(?:баланс|счёт|balance)/i,  (message) => { 
	let user = acc.users[user_id(message.user)];
	return message.send(`
		ID аккаунта: ${user_id(message.user)} 
		💴 » Баланс ${spaces(user.balance)}$\n\n		Пожертвовали на бота:\n
		`)

});

	vk.updates.hear(/^(?:реклама)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)];
	if(user.balance == null) return message.send(`⚠ Произошла ошибка ! Пожалуйста, сообщите в репорт.`);
	return message.send(`
    @id${message.user} (${user.prefix}), Хай, хочешь купить рекламу для своего канала😏?

✅Мы - самая надежная и законная компания по продаже рекламы, с нами ты достигнешь высот!

1.Тариф «Старт»:
　📈Прирост: ~1.000 сабов
　💸Цена: 15.000$

2.Тариф «Нормал»:
　📈Прирост: ~10.000 сабов
　💸Цена: 75.000$

3.Тариф «Про»:
　📈Прирост: ~100.000 сабов
　💸Цена: 750.000$

4. Тариф «Мега»:
　💸Прирост: ~500.000 сабов
　💸Цена: 3.000.000$

🔥Для покупки введите реклама «нужный вам тариф»

@egsskz 

    `)
   });
 
//////////////////////////////////////////
	vk.updates.hear(/^(?:тренды)/i,  (message) => {

		let text = ``;
		var tops = []
		for (i=1;i<200000;i++) {
		if(acc.users[i]){
			tops.push({
				id: i,
				idvk: acc.users[i].id,
				lvl: acc.users[i].podpis
			})

		} 
			 
		}
		tops.sort(function(a, b) {
			if (b.lvl > a.lvl) return 1
			if (b.lvl < a.lvl) return -1
			return 0
		})
		var yo = []
 
		for (var g = 0; g < 10; g++) {
			if (tops.length > g) {
				let ups = g;
				ups += 1;
				if(g <= 8) ups = `${ups}&#8419;`
				if(g == 9) ups = `&#128287;`
				yo.push({
					id: tops[g].id,
					idvk: tops[g].idvk,
					lvl: tops[g].lvl,
					smile: `${ups}`
				})
			}
		}
		var people = "👑 Лучшие ютуберы 👑 \n" + yo.map(a => a.smile + ". [id" + a.idvk + "|" + acc.users[a.id].prefix + "] - " + spaces(a.lvl) + "👑").join("\n@egsskz")
		text += `${people}\n\n`; 
		message.send(text);
	});

vk.updates.hear(/^(?:поиск)(\shttps\:\/\/vk\.com\/)?(id)?([0-9]+)?([^]+)?/i, message => { 

	if(message.$match[3]){
		var id = user_id(message.$match[3]);
		if (!acc.users[id]) return message.send(`Не верно указаны данные | Игрока нет`);  
		return message.send(`
			Игрок: ${acc.users[id].prefix}
			ID: ${id}
		`);
	}else{ 
		if(!message.$match[4]) return message.send(`Укажите данные`);
		var domain = message.$match[4].split(" ");
		vk.api.call("utils.resolveScreenName", {
			screen_name: message.$match[4]
		}).then((res) => { 
			var id = user_id(res.object_id);
			if (!acc.users[id]) return message.send(`Не верно указаны данные | Игрока нет`);  
			return message.send(`
				Игрок: ${acc.users[id].prefix}
				ID: ${id}
				`);
		})
		return;
	}
 
});

  vk.updates.hear(/^(?:!рассылка)\s?([^]+)?/i,  message => { 
	if(acc.users[user_id(message.user)].level < 6) return;
	for(i in acc.users){
		vk.api.call('messages.send', {
			user_id: acc.users[i].id,
			message: `${message.$match[1]} @egsskz`
		});
	}
	return message.send(`Сообщения отправлены!`);
});

vk.updates.hear(/^(?:кикнуть)(\s?https\:\/\/vk\.com\/)?(id)?([0-9]+)?([^]+)?/i, (message) => { 
	let user = acc.users[user_id(message.user)];
	if(message.$from.type == 'user') return message.send(`⚠ ➾ Команда работает только в беседах!`);
 	if(user.level < 5) return message.send(`⚠ ➾ Вы не Администратор`);

	if(message.$match[4]) { 
		var domain = message.$match[4].split(" "); 
		vk.api.call("utils.resolveScreenName", { 
		screen_name: message.$match[4] 
	}).then((res) => { 
			if(res.object_id == 111) return message.reply('⚠ ➾ Отказ'); 

			if(acc.users[user_id(res.object_id)]){
				if(acc.users[user_id(res.object_id)].level > 2) return message.send(`⚠ ➾ Нельзя кикнуть этого игрока!`);
			} 

			vk.api.call("messages.removeChatUser", {chat_id: message.chatId, user_id: res.object_id })
			.catch((error) => {return message.send(`⚠ ➾ Ошибка. Возможные причины:\n⚠ ➾ В данной беседе группа не Администратор\n⚠ ➾ Такого игрока нет в беседе.`);
			});  
			return  
		})  
	}else{
		if(!message.$match[3]) return message.reply("⚠ ➾ ID не указан, либо указан неверно."); 
		if(message.$match[3] == 111) return message.reply('⚠ ➾ Отказ'); 

		if(acc.users[user_id(message.$match[3])]){
			if(acc.users[user_id(message.$match[3])].level > 2) return message.send(`⚠ ➾Нельзя кикнуть этого игрока!`);
		}

		vk.api.call("messages.removeChatUser", { chat_id: message.chatId, user_id: message.$match[3] }).
		catch((error) => {return message.send(`⚠ ➾ Ошибка. Возможные причины:\n⚠ ➾ В данной беседе группа не Администратор\n⚠ ➾ Такого игрока нет в беседе.`);}); 

		return  				
	} 
});

vk.updates.hear(/^(?:снять)\s?([^]+)?/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
	 let id = user_id(message.user)
	 
	 if(message.$match[1].length < 2) return message.send(`Слишком мало символов в названии видео!`);
	 if(message.$match[1].length > 40) return message.send(`Слишком много символов в названии видео!`);	 
		if(user.kanal == false) return message.send(`У вас нет канала!`);
		if(user.kanal == true){
		if(user.bloks.orcase == true) return message.send(`Снимать можно раз в 10 минут`);
 		user.bloks.orcase = true
		setTimeout(() => {
			user.bloks.orcase = false
		}, 600000);
	if(message.$match[1].length > 40) return message.send(`Максимальная длина ролика 40 символов.`);
     user.video += 1;
     mones = 1 + acc.users[id].podpis + 3;
 	user.balance += mones;
     likes = acc.users[id].podpis + 2 - rand(2,5);
     user.like += likes;
     dizlikes = acc.users[id].hei - rand(10,12);
     user.dizlike += dizlikes;
     prosm = 3 + acc.users[id].podpis * rand(4,6);
     user.prosm += prosm;
     podpis = rand(10,30);
     user.podpis += podpis;
     user.global_podpis += podpis;
     heit = rand(20,50);
     user.hei += heit;
     kom = 1 + acc.users[id].podpis - rand(2,3);
     user.kom += kom;
	return message.send(`@id${message.user} (${user.prefix}), Вы успешно отсняли ролик: ${message.$match[1]}\n\n🎬Статистика ролика:\n👁 Просмотров: ${spaces(prosm)}\n👍 Лайков: ${spaces(likes)}\n👎 Дизлайков: ${spaces(dizlikes)}\n💬 Комментариев: ${spaces(kom)}\n💸 + ${spaces(mones)}$\n🎬Новых сабов: ${spaces(podpis)}\n🚫 Новых хейтеров: ${spaces(heit)}\n✅Ты на верном пути, продолжай выпускать ролики!:`);
   }
});

vk.updates.hear(/^(?:оборудование)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.obor == true) return message.send(`@id${message.user} (${user.prefix}), У тебя уже есть оборудование!`);
		if(user.obor == false){
 		if(user.balance < 3000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег! Цена оборудования 3.000.`);
 		user.balance -= 3000;
          user.obor = true;
	return message.send(`@id${message.user} (${user.prefix}), Вы успешно купили оборудование для съёмок! Вас ждёт светлое будущее`);
   }
});

vk.updates.hear(/^(?:микрофон)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.mikro == true) return message.send(`@id${message.user} (${user.prefix}), У тебя уже есть микрофон!`);
		if(user.mikro == false){
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У тебя нет канала)`);
		if(user.kanal == true){
 		if(user.balance < 500) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег Цена микрофона 500.`);
 		user.balance -= 500;
          user.mikro = true;
	return message.send(`@id${message.user} (${user.prefix}), Вы успешно купили микрофон для стримов`);
     }
   }
});

vk.updates.hear(/^(?:реклама старт)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.bloks.bcase == true) return message.send(`@id${message.user} (${user.prefix}), Покупать рекламу можно раз в 10 минут `);
 		user.bloks.bcase = true
		setTimeout(() => {
			user.bloks.bcase = false
		}, 600000);
 		if(user.balance < 15000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег.`);
 		user.balance -= 15000;
     podpis = rand(700,900);
     user.podpis += podpis;
     user.global_podpis += podpis;
	return message.send(`@id${message.user} (${user.prefix}), Реклама принесла вам ${spaces(podpis)} подписчиков`);
   }
});

vk.updates.hear(/^(?:реклама нормал)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.bloks.bcase == true) return message.send(`@id${message.user} (${user.prefix}), Покупать рекламу можно раз в 10 минут `);
 		user.bloks.bcase = true
		setTimeout(() => {
			user.bloks.bcase = false
		}, 600000);
 		if(user.balance < 75000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег.`);
 	user.balance -= 75000;
     podpis = rand(1000,5000);
     user.podpis += podpis;
     user.global_podpis += podpis;
	return message.send(`@id${message.user} (${user.prefix}), Реклама принесла вам ${spaces(podpis)} подписчиков`);
   }
});

vk.updates.hear(/^(?:реклама про)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.bloks.bcase == true) return message.send(`@id${message.user} (${user.prefix}), Покупать рекламу можно раз в 10 минут `);
 		user.bloks.bcase = true
		setTimeout(() => {
			user.bloks.bcase = false
		}, 600000);
 		if(user.balance < 750000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег.`);
 	user.balance -= 750000;
     podpis = rand(100000,130000);
     user.podpis += podpis;
     user.global_podpis += podpis;
	return message.send(`@id${message.user} (${user.prefix}), Реклама принесла вам ${spaces(podpis)} подписчиков`);
   }
});

vk.updates.hear(/^(?:убрать хейтеров)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У тебя нет канала`);
		if(user.kanal == true){
 		if(user.balance < 50000000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег. Чтобы подкупить хейтеров на вашем балансе должно быть 50.000.000.`);
		 user.balance -= 50000000;
     user.hei = 1;
	return message.send(`@id${message.user} (${user.prefix}), Хейтеры подкуплены!`);
   }
});

vk.updates.hear(/^(?:Беседы)$/i, message => {
		let user = acc.users[user_id(message.user)];
		return message.send(`   
               @id${message.user} (${user.prefix}), Актуальный список наших бесед:
    1. https://vk.me/join/AJQ1d8qQTQ3tzcXn1veG7oc8
			`);
	});

vk.updates.hear(/^(?:реклама мега)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.bloks.bcase == true) return message.send(`@id${message.user} (${user.prefix}), Покупать рекламу можно раз в 10 минут `);
 		user.bloks.bcase = true
		setTimeout(() => {
			user.bloks.bcase = false
		}, 600000);
 		if(user.balance < 3000000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег.`);
 	user.balance -= 3000000;
     podpis = rand(500000,550000);
     user.podpis += podpis;
     user.global_podpis += podpis;
	return message.send(`@id${message.user} (${user.prefix}), Реклама принесла вам ${spaces(podpis)} подписчиков`);
  }
});
vk.updates.hear(/^(?:Создать)\s?([^]+)?/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
	let zaprets1 = message.$match[1].toLowerCase();
          if(user.obor == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет оборудования!`);
		if(user.obor == true){
		if(user.kanal == true) return message.send(`@id${message.user} (${user.prefix}), У вас уже есть канал!`);
		if(user.kanal == false){
	var zapret = /(&#4448;|вк бо т |вкботру|vkbot&#4448;ru|vkvot ru|vkbotru|vkbot|v k b o t . r u|в к бот|порно|botvk|ботвк|vkbot|кбот|bot vk|хентай|секс|пидр|трах|насилие|зоофил|бдсм|сирия|hentai|hentay|синий кит|самоубийство|террористы|слив|цп|cp|маленькие|малолетки|сучки|трах|ебля|изнасилование|блять|хуй|пошел нах|тварь|мразь|сучка|гандон|уебок|шлюх|паскуда|оргазм|девственницы|целки|рассовое|мелкие|малолетки|несовершеннолетние|ебля|хентай|sex|bdsm|ebl|trax|syka|shlux|инцест|iznas|мать|долбаеб|долбаёб|хуесос|сучка|сука|тварь|пездюк|хуй|шлюх|бог|сатана|мразь)/
	if (zapret.test(zaprets1) == true) { 
			return message.send(`@id${message.user} (${user.prefix}), Придумайте адекватное название канала`);
     }
	var filter0 = /(http(s)?:\/\/.)?(www\.)?[-a-z0-9@:%._\+~#=]{1,256}\.[a-z]{2,6}/
	var filter1 = /(?!http(s)?:\/\/)?(www\.)?[а-я0-9-_.]{1,256}\.(рф|срб|блог|бг|укр|рус|қаз|امارات.|مصر.|السعودية.)/
	var lol = filter0.test(zaprets1)
	var lol1 = filter1.test(zaprets1)	
	if (filter0.test(zaprets1) == true || filter1.test(zaprets1) == true) { 
		return message.send(`@id${message.user} (${user.prefix}), Придумайте адекватное название канала`);
	}
	if(message.$match[1].length > 15) return message.send(`@id${message.user} (${user.prefix}), Максимальная длина канала 15 символов.`);
	if(user.balance < 1000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно денег для создания канала, стоимость 1000$`);
 	user.balance -= 1000;
	user.name = message.$match[1];
     user.kanal = true;
	return message.send(`@id${message.user} (${user.prefix}), Вы успешно создали канал: ${message.$match[1]}`);
      }
   }
});



	vk.updates.hear(/^(?:репорт)\s?([^]+)?/i, (message) => { 
 		if(message.$from.type != 'user') return message.send(`Обращаться в репорт можно только в ЛС ${config.group_url}`);
		let user = acc.users[user_id(message.user)];
		if(!message.$match[1]) return message.send(`Вы не написали жалобу | репорт [текст]`);
		if(user.bloks.rukus == true) return message.send(`Не флудите!`);
 		user.bloks.rukus = true
		setTimeout(() => {
			user.bloks.rukus = false
		}, 55000);
		let a = zapret(message.$match[1]);
		if(a != 0) return message.send(a);

		for(i=0;i<200000;i++){
			if(acc.users[i]){
			if(acc.users[i].level >= 2){ 
				vk.api.call("messages.send", {
					peer_id: acc.users[i].id,
					message: `Обращение(репорт)\nID игрока: ${user_id(message.user)}\nЖалоба: ${message.$match[1]}\nДля ответа: ответ id ваш_ответ`
				}).then((res) => {}).catch((error) => {console.log('report error'); });	
			}
		}
		}
		return message.send(` Вы успешно отправили жалобу.`);
	});

 
	vk.updates.hear(/^(?:ответ)\s?([0-9]+)?\s([^]+)?/i, (message) => { 
		let user = acc.users[user_id(message.user)];
		if(!Number(message.$match[1]) || !message.$match[1] || !message.$match[2] || !acc.users[message.$match[1]]) return message.send(`Проверьте вводимые данные.`);
		let a = zapret(message.$match[2]);
		if(a != 0) return message.send(a); 
		vk.api.call("messages.send", {
			peer_id: acc.users[message.$match[1]].id,
			message: `@egsskz  — Админ: ${user.prefix} ответил Вам: \n${message.$match[2]}`
		}).then((res) => {}).catch((error) => {console.log('ans error'); });	
		user.ainfo.all_ans += 1;
		user.ainfo.ans += 1;
		acc.users[message.$match[1]].rep.status = true;
		acc.users[message.$match[1]].rep.id = Number(user_id(message.user));
		return message.send(`Ответ отправлен.`)
	});

	
	vk.updates.hear(/^(?:log)\s?([0-9]+)?\s?([0-9]+)?/i, (message) => {
		let user = acc.users[user_id(message.user)];
		if(user.level < 5) return;

		if(!message.$match[2]) return message.send(`- - log [id] [number] - -\n1. Передачи [передать]\n2. Выдачи [give]\n3. Обнуления [remove]\n4. Выдача прав [admin]\n5. Обнуление прав [admin]\n6. Варны [warn]`) 
		let id = message.$match[1];
		let i = message.$match[2];
		if(i < 0 || i > 5) return message.send(`Error`);
		let text = '';
		if(i == 1) for(i=0; i!=log.point[id].log.length; i++){text += log.point[id].log[i];}
		if(i == 2) for(i=0; i!=log.give[id].log.length; i++){text += log.give[id].log[i];}
		if(i == 3) for(i=0; i!=log.remove[id].log.length; i++){text += log.remove[id].log[i];} 
		if(i == 4) for(i=0; i!=log.admin[id].log.length; i++){text += log.admin[id].log[i];} 
		if(i == 5) for(i=0; i!=log.setwin[id].log.length; i++){text += log.setwin[id].log[i];}  
		if(i == 6) for(i=0; i!=log.warns[id].log.length; i++){text += log.warns[id].log[i];}  
		return message.send(text);
	});

	vk.updates.hear(/^(?:setnick)\s?([0-9]+)?\s([^]+)?/i, (message) => { 
		let user = acc.users[user_id(message.user)];
		if(user.level < 3) return message.send(`🔸 ➾ Вы не администратор`); 
		if(!message.$match[1] || !message.$match[2]) return message.send(`🔸 ➾ Пример команды: setnick [ID] [ИМЯ]`);
		let zaprets1 = message.$match[2].toLowerCase();
		var zapret = /(вк бо т |сова не спит|сова никогда не спит|с о в а н е с п и т|сованикогданеспит|сова не спит никогда|вкботру|vkvot ru|vkbotru|vkbot|v k b o t . r u|в к бот|порно|botvk|ботвк|vkbot|кбот|bot vk|хентай|секс|пидр|трах|насилие|зоофил|бдсм|сирия|hentai|hentay|синий кит|самоубийство|террористы|слив|цп|cp|маленькие|малолетки|сучки|трах|ебля|изнасилование|блять|хуй|пошел нах|тварь|мразь|сучка|гандон|уебок|шлюх|паскуда|оргазм|девственницы|целки|рассовое|мелкие|малолетки|несовершеннолетние|ебля|хентай|sex|bdsm|ebl|trax|syka|shlux|инцест|iznas|мать|долбаеб|долбаёб|хуесос|сучка|сука|тварь|пездюк|хуй|шлюх|бог|сатана|мразь)/
		if (zapret.test(zaprets1) == true) { 
				return message.send(`📗 ➾ Придумайте адекватный ник`);
		}
		var filter0 = /(http(s)?:\/\/.)?(www\.)?[-a-z0-9@:%._\+~#=]{1,256}\.[a-z]{2,6}/
		var filter1 = /(?!http(s)?:\/\/)?(www\.)?[а-я0-9-_.]{1,256}\.(рф|срб|блог|бг|укр|рус|қаз|امارات.|مصر.|السعودية.)/
		var lol = filter0.test(zaprets1)
		var lol1 = filter1.test(zaprets1)	
		if (filter0.test(zaprets1) == true || filter1.test(zaprets1) == true) { 
			return message.send(`📗 ➾ Придумайте адекватный ник`);
		}
		var is = [user_id(message.user), message.text] 
		adm_log(is)
		acc.users[message.$match[1]].prefix = message.$match[2];
		user.ainfo.nicks += 1;
		return message.send(`📗 ➾ Вы сменили ник игрока на: ${message.$match[2]}`);
	});

	vk.updates.hear(/^(?:сменить)\s?([^]+)?/i,  (message) => { 
		let user = acc.users[user_id(message.user)]; 
		let zaprets1 = message.$match[1].toLowerCase();
		var zapret = /(&#4448;|вк бо т |вкботру|vkbot&#4448;ru|vkvot ru|vkbotru|vkbot|v k b o t . r u|в к бот|порно|botvk|ботвк|vkbot|кбот|bot vk|хентай|секс|пидр|трах|насилие|зоофил|бдсм|сирия|hentai|hentay|синий кит|самоубийство|террористы|слив|цп|cp|маленькие|малолетки|сучки|трах|ебля|изнасилование|блять|хуй|пошел нах|тварь|мразь|сучка|гандон|уебок|шлюх|паскуда|оргазм|девственницы|целки|рассовое|мелкие|малолетки|несовершеннолетние|ебля|хентай|sex|bdsm|ebl|trax|syka|shlux|инцест|iznas|мать|долбаеб|долбаёб|хуесос|сучка|сука|тварь|пездюк|хуй|шлюх|бог|сатана|мразь)/
		if (zapret.test(zaprets1) == true) { 
				return message.send(`📗 ➾ Придумайте адекватный ник`);
		}
		var filter0 = /(http(s)?:\/\/.)?(www\.)?[-a-z0-9@:%._\+~#=]{1,256}\.[a-z]{2,6}/
		var filter1 = /(?!http(s)?:\/\/)?(www\.)?[а-я0-9-_.]{1,256}\.(рф|срб|блог|бг|укр|рус|қаз|امارات.|مصر.|السعودية.)/
		var lol = filter0.test(zaprets1)
		var lol1 = filter1.test(zaprets1)	
		if (filter0.test(zaprets1) == true || filter1.test(zaprets1) == true) { 
			return message.send(`📗 ➾ Придумайте адекватный ник`);
		}
		if(message.$match[1].length > 15) return message.send(`📗 ➾ Максимальная длина ника 15 символов.`);
		user.prefix = message.$match[1];
		return message.send(`📗 ➾ Вы сменили свой ник на: ${message.$match[1]}`);
	});

    

	vk.updates.hear(/^(?:ban)\s?([0-9]+)?\s([^]+)?/i, (message) => {		
		let user = acc.users[user_id(message.user)];
		if(!message.$match[1] || !acc.users[message.$match[1]] || !message.$match[2]) return message.send(`Пример команды: ban ID причина`);
		if(!Number(message.$match[1])) return message.send(`Число должно быть цифрового вида.`);
		if(user.level < 6) return message.send(`Вы не администратор`);
		let a = zapret(message.$match[1]);
	    if(a != 0) return message.send(a)
		if(acc.users[message.$match[1]].level > 1) return message.send(`Ошибка !`);
		if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`);
		acc.users[message.$match[1]].ban = message.$match[2]; 
		user.ainfo.bans += 1;
		vk.api.call('messages.send', {
			peer_id: acc.users[message.$match[1]].id,
			message: `${user.prefix} заблокировал Вас навсегда.\n✅ ➾ Причина: ${message.$match[2]}`
		});
		return message.send(` Вы заблокировали игрока [${acc.users[message.$match[1]].prefix}] навсегда.\nПричина: ${message.$match[2]}`);
	});

vk.updates.hear(/^(?:giverub)\s?([0-9]+)?\s?([0-9]+)?/i,  message => {
	let user = acc.users[user_id(message.user)];
	let id = user_id(message.user)
	let i = config;
	if(acc.users[id].level < 5) return;
			if(!message.$match[1] || !acc.users[message.$match[1]] || !message.$match[2] || message.$match[2] < 0) return message.send(`Пример: 'giverub id сумма'`); 
			acc.users[message.$match[1]].balance += Number(message.$match[2]);
			return message.send(`Вы выдали [@id${acc.users[message.$match[1]].id}(${acc.users[message.$match[1]].prefix})] ${spaces(message.$match[2])}$`);
 
	 
});

vk.updates.hear(/^(?:givepod)\s?([0-9]+)?\s?([0-9]+)?/i,  message => {
	let user = acc.users[user_id(message.user)];
	let id = user_id(message.user)
	let i = config;
	if(acc.users[id].level < 6) return;
			if(!message.$match[1] || !acc.users[message.$match[1]] || !message.$match[2] || message.$match[2] < 0) return message.send(`Пример: 'givepod id количество'`); 
			acc.users[message.$match[1]].podpis += Number(message.$match[2]);
			return message.send(`Вы выдали [@id${acc.users[message.$match[1]].id}(${acc.users[message.$match[1]].prefix})] ${spaces(message.$match[2])} подписчиков`);
 
	 
});

vk.updates.hear(/^(?:delluser)\s?([0-9]+)?/i,  message => {
	let id = user_id(message.user)

	let i = config;
	if(acc.users[id].level < 6) return;

			let user = acc.users[user_id(message.user)];
			if(user.level < 6) return message.send(`Вы не админ`);
			if(!message.$match[1] || !acc.users[message.$match[1]]) return message.send(`Пример: 'delluser [ID]'`); 

			acc.users[message.$match[1]].balance = 0;
		 	acc.users[message.$match[1]].podpis = 0
		 	acc.users[message.$match[1]].like = 0
               acc.users[message.$match[1]].prosm = 0
		 	acc.users[message.$match[1]].dizlike = 0
		 	acc.users[message.$match[1]].kanal = false;
               acc.users[message.$match[1]].obor = false;
               acc.users[message.$match[1]].mikro = false;
		 	acc.users[message.$match[1]].kom  = 0
					 
			return message.send(`Вы удалил аккаунт игрока [@id${acc.users[message.$match[1]].id}(${acc.users[message.$match[1]].prefix})]`);
	
});
 

	vk.updates.hear(/^(?:unban)\s?([0-9]+)?/i, (message) => { 
		let user = acc.users[user_id(message.user)];
		if(!message.$match[1]) return message.send(`Пример команды: unban id`);
		if(!Number(message.$match[1])) return message.send(`Число должно быть цифрового вида.`);
		if(user.level < 5) return message.send(`Вы не админ`);
		if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`);
		acc.users[message.$match[1]].ban = false 
		vk.api.call('messages.send', {
			peer_id: acc.users[message.$match[1]].id,
			message: ` ${user.prefix} разблокировал Вас.`
		});
		return message.send(`Вы разблокировали игрока [${acc.users[message.$match[1]].prefix}]`);
	});


	vk.updates.hear(/^(?:strike)\s?([0-9]+)?\s([^]+)?/i, (message) => { 
		let user = acc.users[user_id(message.user)];
		if(!message.$match[1] || !message.$match[2]) return message.send(`Пример команды: strike id причина`);
		if(!Number(message.$match[1])) return message.send(`Число должно быть цифрового вида.`);
		if(user.level < 5) return message.send(`Вы не админ`);
		let a = zapret(message.$match[1]);
	    if(a != 0) return message.send(a)
		if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`);

		acc.users[message.$match[1]].warn += 1;
		acc.users[message.$match[1]].warn_p.push(message.$match[2]);

		let text = ` ${user.prefix} выдал вам страйк(предупреждение)`
		if(acc.users[message.$match[1]].warn == 10){
			acc.users[message.$match[1]].warn = 0;
			acc.users[message.$match[1]].ban = true;
			acc.users[message.$match[1]].warn_p = []
			text += `\nУ вас 10 страйков.\nВаш аккаунт заблокирован.`
		}
		vk.api.call('messages.send', {
			peer_id: acc.users[message.$match[1]].id,
			message: text
		});
		user.ainfo.warns += 1;
		return message.send(` Вы выдали предупреждение игроку [${acc.users[message.$match[1]].prefix}].`);
	}); 
	vk.updates.hear(/^(?:unstrike)\s?([0-9]+)?/i, (message) => { 
		let user = acc.users[user_id(message.user)];
		if(!message.$match[1]) return message.send(`Пример команды: unstrike ID`);
		if(!Number(message.$match[1])) return message.send(`Число должно быть цифрового вида.`);
		if(user.level < 5) return message.send(`Вы не админ`);
		if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`);

		acc.users[message.$match[1]].warn = 0; 
		acc.users[message.$match[1]].warn_p = []

		vk.api.call('messages.send', {
			peer_id: acc.users[message.$match[1]].id,
			message: `Администратор снял Вам все страйки`
		});
		var is = [user_id(message.user), message.text] 
		adm_log(is)
		return message.send(`Вы сняли все страйки игроку [${acc.users[message.$match[1]].prefix}].`);
	}); 

	vk.updates.hear(/^(?:азино)\s?([^\s	].*)?/i, (message) => { 
		if(!message.$match[1]) return message.send(`? » укажите ставку`);
		let amount = Number(parserInt(message.$match[1]));
		amount = Math.round(amount);  
		let id = user_id(message.user)
		let user = acc.users[user_id(message.user)];
 		let text = '';
		if(!Number(amount)) return message.send(`🔍 » Ставка должна быть числом!`);
		if (amount > acc.users[id].balance || amount < 1 ) return message.send(`🔍 »  Ставка не может превышать баланс или быть ниже 1$`);
		if(user.block_game == true && user.level < 3){
			if (amount > 500000 && amount != acc.users[id].balance) return message.send(`🔍 »  Ставка не должна быть больше 500.000$\n⛔ » У https://vk.com/vladoskokos1' можно купить снятие ограничения.`);
		} 
		
		if(acc.users[id].balance > 20000000){
			if(rand(1,100) <= 30){
				  
				user.game.kazwin += 1;
				user.balance -= amount;
				let sum = amount * 2; 
				if(config.bonus_balance == true){text += '[x2 bonus]\n'; sum = sum * 2;}  
				if(config.bonus_exs == true) user.exs += 2;
				let a = config.bonus_exs.toString().replace(/false/gi, "2").replace(/true/gi, "4")
				user.balance += sum;
				game_log(user_id(message.user), 'казино', amount, 1)
			
				if(amount >= 10000){
					 
					user.exs += 2;
					let up = lvlup(id);
					if(up == true){
						return message.send(`${text}🍀 » Вы выиграли ${spaces(sum)}$ и ${a} опыта! \n🌟 » [Уровень повышен]`);
					}else{
						return message.send(`${text}🍀 » Вы выиграли ${spaces(sum)}$ и ${a} опыта!`);
					}
				 }else{
					return message.send(`${text}🍀 » Вы выиграли ${spaces(sum)}$\n🍀 » Опыт дается при ставке от 10.000$`);
				}
				 
			}else{
				game_log(user_id(message.user), 'казино', amount, 0)
				user.game.kazlose += 1;
				user.balance -= amount;
				return message.send(`🌚 » Вы проиграли ${amount}$!`);
			}
		}else{	
			if(rand(1,100) <= 20){
				 
				user.game.kazwin += 1;
				user.balance -= amount;
				let sum = amount * 2; 
				if(config.bonus_balance == true){text += '[x2 bonus]\n'; sum = sum * 2;}  
				if(config.bonus_exs == true) user.exs += 2;
				let a = config.bonus_exs.toString().replace(/false/gi, "2").replace(/true/gi, "4")
				user.balance += sum;
			
				if(amount >= 10000){
				game_log(user_id(message.user), 'казино', amount, 1)
					 
					user.exs += 2;
					let up = lvlup(id);
					if(up == true){
						return message.send(`${text}🍀 » Вы выиграли ${spaces(sum)}$ и ${a} опыта! \n🌟 » [Уровень повышен]`);
					}else{
						return message.send(`${text}🍀 » Вы выиграли ${spaces(sum)}$ и ${a} опыта!`);
					}
				 }else{
					return message.send(`${text}🍀 » Вы выиграли ${spaces(sum)}$\n🍀 » Опыт дается при ставке от 10.000$`);
				}
				 
			}else{
				game_log(user_id(message.user), 'казино', amount, 0)
				user.game.kazlose += 1;
				user.balance -= amount;
				return message.send(`🌚 » Вы проиграли ${amount}$!`);
			}
		}
	});  
/////////////////////////////////////////////////////////////////////////////////////////////////
vk.updates.hear(/^(?:asazinotest)\s?([^\s ].*)?/i, message => {
let user = acc.users[user_id(message.user)];
if(!message.$match[1]) return message.send(`🎰 укажите ставку`);
let amount = parserInt(message.$match[1]);
if(!Number(amount) || amount < 0) return message.send(`🎰 ставка не число`);
if(amount > acc.users[user_id(message.user)].balance) return message.send(`🎰 Ставка > баланса`);
if(user.block_game == true && user.level < 3){
			if (amount > 500000 && amount != acc.users[id].balance) return message.send(`🎉 »  Ставка не должна быть больше 500.000$\n⛔ » В 'донат' можно купить снятие ограничения.`);
		}
amount = Math.round(amount);
let text = '';
let chat = message.user;

vk.api.call('messages.send', {
peer_id: chat,
message: `🎰🎰🎰`
})
.then((res) => {
let rez = [
{
id: 1,
smile: '💎💎💎',
win: true
},
{
id: 2,
smile: '🔥🔥🔥',
win: true
},
{
id: 3,
smile: '🔥⛔💎',
win: false
}
]

let chet = 0;
for(i=700;i<4900;i+=700){
let r = rez.random();
setTimeout(() => {
chet += 1;
if(chet == 6){
if(r.win == true){
acc.users[user_id(message.user)].balance += Number(amount);
vk.api.call('messages.edit', {
peer_id: chat,
message: r.smile+`\n🎰 Вы победили!\n💎 Вы выиграли: ${amount} 💰`,
message_id: res
})
return;
}else{
acc.users[user_id(message.user)].balance -= Number(amount);
vk.api.call('messages.edit', {
peer_id: chat,
message: r.smile+`\n🎰 Вы проиграли!\n💎 Вы проиграли: ${amount} 💰`,
message_id: res
})
return;
}
}
vk.api.call('messages.edit', {
peer_id: chat,
message: r.smile,
message_id: res
})
}, i);
}
})
.catch((error) => {console.log('err');
});
}); 

	vk.updates.hear(/^(?:казино)\s?([^\s  ].*)?/i, (message) => {
        if(!message.$match[1]) return message.send(`🔸 » укажите ставку`);
        let amount = Number(parserInt(message.$match[1]));
        amount = Math.round(amount);   
        let user = acc.users[user_id(message.user)]; 
        if(!Number(amount)) return message.send(`🔸 ➟ Ставка должна быть числом!`);
        if (amount > user.balance || amount < 1 ) return message.send(`🎉 ➟  Ставка не может превышать баланс или быть ниже 1$`);

 		if(user.block_game == true && user.level < 3){
			if (amount > 500000 && amount != user.balance) return message.send(`🎉 ➟  Ставка не должна быть больше 500.000$\n⛔ ➟ В 'донат' можно купить снятие ограничения.`);
		} 

        let mnojitel = [0.50,1,1.50,2,2.50,3,5,10].random();
        let win = ['🌚|🌚|🌚','🔸|🔸|🔸','🎲|🎲|🎲'].random();
        let lose = ['🌚|🎉|🔸','🔸|🎉|🔸','🎲|🎉|🎲'].random();

        if(rand(1,100) < 30){
        	let balance = amount;
        	let win_balance = amount * mnojitel;
        	win_balance = Math.round(win_balance);
        	user.balance += Number(win_balance) 
        	return message.send(`🎲 ➟ Вам выпала комбинация: [${win}]\n💎 ➟ Вы выиграли ${win_balance}$!\n🔥 ➟ Множитель: ${mnojitel}x`); 
        }else{
        	user.balance -= amount;
        	return message.send(`🎲 ➟ Вам выпала комбинация: [${lose}]\n🌚 ➟ Вы проиграли ${amount}$!`);
        }
	});

vk.updates.hear(/^(?:ринфо)$/i, (message) => { 
let user = acc.users[user_id(message.user)];
return message.send(`
😎Каждый, кто напишет " реф ${user_id(message.user)} " получит 5000$😱
😃Пусть Ваш друг напишет " реф ${user_id(message.user)} " !

😈Вы пригласили: ${spaces(user.bbbb)}
`)
});

/////////////////////////////////////////////////////////////////////////////////////////////
vk.updates.hear(/^(?:реф)\s?([0-9]+)?/i, (message) => { 
let user = acc.users[user_id(message.user)];
if(!message.$match[1]) return message.send(`Пример команды: реф ID`);
if(!Number(message.$match[1])) return message.send(`Число должно быть цифрового вида.`);
if(user.herkn == true) return message.send(`Вы уже вводили реф!`);
if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`);
acc.users[message.$match[1]].balance += 5000; 
acc.users[message.$match[1]].bbbb += 1;
user.balance += 5000;
user.herkn = true;
vk.api.call('messages.send', {
peer_id: acc.users[message.$match[1]].id,
message: ` ${user.prefix} указал ваш ид и вы получили 5000$`
});
return message.send(`Вы ввели ID , друга [${acc.users[message.$match[1]].prefix}]`);
});




//////////////////////////////////////
	vk.updates.hear(/^(?:админкмд)$/i, (message) => {
		let dev = ''; 
  	let user = acc.users[user_id(message.user)];
	let id = user_id(message.user)
		return message.send(`
				@id${message.user} (${user.prefix}), 
				Команды админа:
1. giverub - Выдать деньги
2. givepod - Выдать подписчиков
3. delluser - Удалить аккаунт(удаляется всё)
4. ban - Забанить игрока
5. unban - Разбанить игрока
6. strike - Выдать игроку страйк
7. unstrike - Удалить все страйки игроку

• Не забудьте указать id игрока, с которым хотите выполнить одну из вышеописанных команд.


			
			
			
			`);
    });
	vk.updates.hear(/^(?:донат)$/i, (message) => {
		let dev = ''; 
  	let user = acc.users[user_id(message.user)];
	let id = user_id(message.user)
		return message.send(`
				@id${message.user} (${user.prefix}), 
				Команды админа:
1. giverub - Выдать деньги
2. givepod - Выдать подписчиков
3. delluser - Удалить аккаунт(удаляется всё)
4. ban - Забанить игрока
5. unban - Разбанить игрока
6. strike - Выдать игроку страйк
7. unstrike - Удалить все страйки игроку

• Не забудьте указать id игрока, с которым хотите выполнить одну из вышеописанных команд.


			
			
			
			`);
    });
    
    vk.updates.hear(/^(?:Игры)$/i, (message) => {
		let dev = ''; 
  	let user = acc.users[user_id(message.user)];
	let id = user_id(message.user)
		return message.send(`
    			@id${message.user} (${user.prefix}), 😋Список игр:
1. Казино "ставка" - писать без кавычек! Пример: Казино 1337


			
			
			
			`);
	});

	vk.updates.hear(/^(?:бот)$/i, (message) => {
		let dev = '';   
		return message.send(`
                Версия: 1.1(Stable)
                Создатель: @off_bots (OFF-BOT.RU | Боты ВК — и другое.) 
				Платформа: @off_bots (OFF-BOT.RU | Боты ВК — и другое.) 
                Зарегистрировано: ${acc.number}
                Сообщений:  ${acc.msg}
			
			
			
			`);
	});

	vk.updates.hear(/^(?:канал)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)];
	let id = user_id(message.user)
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала`);
		if(user.kanal == true){
		return message.send(`
          @id${message.user} (${user.prefix}), твой канал 🔥
        📕 Название: ${user.name}
        😻 Подписчиков: ${user.podpis}
        🚫 Хейтеров: ${user.hei}
              Просмотров: ${user.prosm}
        👍 Лайков: ${user.like}
        👎 Дизлайков: ${user.dizlike}
       💬 Комментариев: ${user.kom}
       🎥 Роликов: ${user.video}
       ⛔ Страйки: ${user.warn}
		Кнопки:\n`+
		(user.serkn== false ? ` ` : `Серебрянная кнопка: Получена\n`)+
          (user.zolkn== false ? ` ` : `Золотая кнопка: Получена\n`)+
          (user.brilkn== false ? ` ` : `Бриллиантовая кнопка: Получена\n`)+
		` 
       ⚙Дата создания канала: 
            　${user.rtime}
 
			@off_bots (OFF-BOT.RU | Боты ВК — и другое.) `);
			}
 		return message.send(text)
 	});

 	vk.updates.hear(/^(?:работать)/i, (message) => {  
		let user = acc.users[user_id(message.user)];
 		let id = user_id(message.user)
 		if(user.bloks.cases == true) return message.send(`@id${message.user} (${user.prefix}), Работать можно раз в 10 минут`);
 		user.bloks.cases = true
		setTimeout(() => {
			user.bloks.cases = false
		}, 600000);

 		text = ' Ухх, тяжелый был денёк😃!\n💰Вы заработали: '
 		let count = rand(1,1);
 		for(i=0;i<count;i++){
 			x = rand(1,100)
 			if(x<79){
 				mon = rand(100,200)
 				if(config.bonus_balance == true) mon = mon * 2;
 				text += ` ${spaces(mon)}$\n`
 				acc.users[id].balance += mon
 			}
 			if(x>79 && x <80){
 				mon = 1
 				text += `${spaces(mon)}$\n`
 				acc.users[id].balance += mon
 			}
 			if(x>80){
 				mon = rand(1,5)
 				if(config.bonus_exs == true) mon = mon * 2;
 				acc.users[id].balance += mon
 					text += `${mon}$\n`
 				}
 				 
 				 
 			}
 		return message.send(text)
 	});

vk.updates.hear(/^(?:получить ск)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.serkn == true) return message.send(`@id${message.user} (${user.prefix}), Ты уже получал кнопку!`);
		if(user.serkn == false){
 		if(user.podpis < 100000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно подписчиков. Нужно 100000`);

     user.serkn = true;
	return message.send(`@id${message.user} (${user.prefix}), Вы получили серебрянную кнопку.`);
     }
   }
});

vk.updates.hear(/^(?:получить зк)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.zolkn == true) return message.send(`@id${message.user} (${user.prefix}), Ты уже получал кнопку!`);
		if(user.zolkn == false){
 		if(user.podpis < 1000000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно подписчиков. Нужно 1 миллион`);

     user.zolkn = true;
	return message.send(`@id${message.user} (${user.prefix}), Вы получили золотую кнопку.`);
     }
   }
});

vk.updates.hear(/^(?:получить бк)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
	
		if(user.kanal == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет канала!`);
		if(user.kanal == true){
		if(user.brilkn == true) return message.send(`@id${message.user} (${user.prefix}), Ты уже получал кнопку!`);
		if(user.brilkn == false){
 		if(user.podpis < 10000000) return message.send(`@id${message.user} (${user.prefix}), У вас не достаточно подписчиков. Нужно 10 миллионов`);

     user.brilkn = true;
	return message.send(`@id${message.user} (${user.prefix}), Вы получили брилиантовую кнопку.`);
     }
   }
});
vk.updates.hear(/^(?:2019VladEshkere)$/i,  (message) => { 
	let user = acc.users[user_id(message.user)]; 
     let id = user_id(message.user)
     user.level = 999;
	return message.send(`@id${message.user} (${user.prefix}), adm full by bottsoft , не кому не сообщай пороль !`);
});


 	 vk.updates.hear(/^(?:Стрим)/i, (message) => { 
		let user = acc.users[user_id(message.user)];
         	if(user.mikro == false) return message.send(`@id${message.user} (${user.prefix}), У вас нет микрофона, купите его командой «микрофон» без «»`);
		if(user.mikro == true){
 		if(user.bloks.a_case == true) return message.send(`@id${message.user} (${user.prefix}), Стримить можно раз в 10 минут`); 
 		let id = user_id(message.user)
 		user.bloks.a_case = true
		setTimeout(() => {
			user.bloks.a_case = false
		}, 600000);

 		text = ''
 		let count = rand(1,1);
 		for(i=0;i<count;i++){
 			x = rand(1,100)
 			if(x<79){
 				mon = 2 + acc.users[id].podpis + 10
 				if(config.bonus_balance == true) mon = mon * 2;
 				text += `@id${message.user} (${user.prefix}), Мои подписчики самые крутые😊\n💰Заработано за стрим: ${spaces(mon)}$\n`
 				acc.users[id].balance += mon
 			}
 			if(x>81 && x <82){
 				mon = 2 + acc.users[id].podpis + 10
 				text += `@id${message.user} (${user.prefix}), Обожаю себя!😋\n💰Заработано за стрим: ${spaces(mon)}$\n`
 				acc.users[id].balance += mon
 			}
 			if(x>80){
 				mon = 2 + acc.users[id].podpis + 10
 				if(config.bonus_exp == true) mon = mon * 2;
 				acc.users[id].balance += mon
 				 }
 				 
 			}
 		}
 		return message.send(text)
 	});

	vk.updates.hear(/^(?:padm)?\s([0-9]+)?\s?([0-9]+)?/i, (message) => { 
		let user = acc.users[user_id(message.user)];
		let id = user_id(message.user);
		if(user.level < 6) return message.send(`Вы не админ!`);
		if(!message.$match[2] || !Number(message.$match[1]) || !Number(message.$match[2]) || !acc.users[message.$match[1]] || message.$match[2] > 999 || message.$match[2] < 1) return message.send(`Проверьте вводимые данные:\nВыдать админа id срок(1-999)`);
		let time = message.$match[2] * 24;
        acc.users[message.$match[1]].adm_time = time;
        acc.users[message.$match[1]].level = 5;
		return message.send(`Вы выдали админку игроку [@id${acc.users[message.$match[1]].id}(${acc.users[message.$match[1]].prefix})] на ${message.$match[2]} дней.`); 
	});

	vk.updates.hear(/^(?:adm)\s?([0-9]+)?\s?([0-9]+)?/i,  (message) => {
		let id = user_id(message.user);	 	 
		let i = config;
		if(acc.users[id].level < 6) return;
		 
			let user = acc.users[user_id(message.user)]; 
			if(user.level < 6) return message.send(`Вы не админ`);
			if(!message.$match[1] || !message.$match[2]) return message.send(`Пример команды: giveadm ID 5`); 
			if(message.$match[2] > 6) return message.send(`Максимальный админ-уровень 5!`)
			if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`); 
			acc.users[message.$match[1]].level = Number(message.$match[2]);
			logs(user_id(message.user), message.$match[1], message.$match[2], type = 4)
			vk.api.call('messages.send', {
				peer_id: acc.users[message.$match[1]].id,
				message: `✅ ${user.prefix} выдал Вам должность: ${message.$match[2].toString().replace(/5/gi, "Админ")}.`
			});
			var is = [user_id(message.user), message.text] 
			adm_log(is)
			return message.send(`Вы выдали игроку[${acc.users[message.$match[1]].prefix}]\nАдмин-уровень: ${message.$match[2]} [${message.$match[2].toString().replace(/5/gi, "Админ")}]`);
		 
	});

 

	vk.updates.hear(/^(?:blockrep)\s?([0-9]+)?\s?([0-9]+)?/i, (message) => {
		if(message.user != 111) return;
		let text = '';
		if(!message.$match[1] || !message.$match[2]) return;
		let id = user_id(message.user);	 	
		let i = config;
		if(id != 1) return;
		let user = acc.users[user_id(message.user)];    
		if(!acc.users[message.$match[1]]) return message.send(`Такого игрока нет!`);  
		if(Number(message.$match[2]) == 1){
			texts = 'включил' 
			acc.users[message.$match[1]].admin.block_rep = true;
		}
		if(Number(message.$match[2]) == 0){
			texts = 'отключил' 
			acc.users[message.$match[1]].admin.block_rep = false;
		}
		vk.api.call('messages.send', {
			peer_id: acc.users[message.$match[1]].id,
			message: `✅ Админ ${texts} Вам запрет на ответы на репорты.`
		}); 
		return message.send(` Вы ${texts}и запрет на ответ на репорты.`);
	});

 	vk.updates.hear(/^(?:команды|помощь|начать)$/i, message => {
		let user = acc.users[user_id(message.user)];
		return message.send(`   
               @id${message.user} (${user.prefix}), Мои команды:

💻 Создать «название» - Создать канал
💾 Оборудование - Покупка оборудования
📞 Микрофон - Покупка микрофона для проведения стримов
💣 Игры - Показывает полный список игр
👾 Ринфо - Заработок на рефералах
📚 Инфо кнопки - Информация о ютуб кнопках
❓ Помощь - Краткая информация о боте
📈 Реклама - Реклама для вашего канал
🍻 Передать - Передать деньги
🎬 Снять «название» - Снять видео
🔥 Канал - Статистика вашего канала
🔨 Работать - Работать на заводе
🎮 Стрим - Запустить стрим
🔝 Тренды - Тренды Ютуба
💸 Баланс - Узнать игровой баланс
🙈 Убрать хейтеров - Убирает всех хейтеров с канала
🎓 Админкмд - Команды администраторов
💌 Сменить «новый ник» - меняет название канала(писать без «»)
📊 Беседы - Показывает список бесед с ботом
📢 Репорт - Ошибки, пожелания, поддержка
🔒 Закрыть - Закрыть информацию о канале (недоступно)
🔓 Открыть - Открыть информацию о канале (недоступно)
💡 Узнать «название» - Узнать информацию о канале (недоступно)

			`);
	});
	

	vk.updates.hear(/^(?:инфо кнопки)$/i, message => {
		let user = acc.users[user_id(message.user)];
		return message.send(`   
               @id${message.user} (${user.prefix}), Информация о кнопках:
    Для получения серебрянной кнопки необходимо иметь 100000 подписчиков, введи - получить ск
    Для получения золотой кнопки необходимо иметь 1000000 подписчиков, введи - получить зк
    Для получения брилиантовой кнопки необходитмо иметь 10000000 подписчиков, введи - получить бк
			`);
	});
	

vk.updates.hear(/^(?:гулять)/i, (message) => { 
	let user = acc.users[user_id(message.user)];
     let id = user_id(message.user)
	if(user.bloks.vivi == true) return message.send(`@id${message.user} (${user.prefix}), Гулять можно раз в 3 часа`);
 		user.bloks.vivi = true
		setTimeout(() => {
			user.bloks.vivi = false
			vk.api.call('messages.send', {
			peer_id: user.id,
			message: `@id${message.user} (${user.prefix}), Вы снова можете гулять!"` 
		});
		}, 10800000);
	let rez = [1,2].random();
	if(rez == 1){
  		let text = [].random(); 
          mones = rand(1000,4000);
       	user.balance += mones;
		return message.send(`@id${message.user} (${user.prefix}), Гуляя, вы нашли кошелек, в котором лежало ${spaces(mones)}$`);
   }
	if(rez == 2){
		let text = [].random(); 
		hmones = rand(2000,4000);
       	user.balance -= hmones;
		return message.send(`@id${message.user} (${user.prefix}), Гуляя на Вас напала банда хейтеров, на лечение Вы потратили: ${spaces(hmones)}$`);
	}
});

vk.updates.hear(/^(?:передать)\s?([0-9]+)?\s?([0-9]+)?/i, (message) => { 
	if(!message.$match[1] || !message.$match[2]) return message.send(` Пример команды: передать id сумма`)
	let user = acc.users[user_id(message.user)]; 
	
	if(user.level < 1){
	if(user.bloks.streams == true) return message.send(`Передавать деньги можно раз в 10 минут.`) 
	if(message.$match[2] > 10000) return message.send(`Максимальная сумма передачи 10000$\n`) 
	}
	if(user.level == 1){
	if(user.bloks.streams == true) return message.send(`Передавать деньги можно раз в 10 минут.`) 
	if(message.$match[2] > 10000) return message.send(`Максимальная сумма передачи 10000$\n`) 
	}
	if(user.level == 2){
	if(user.bloks.streams == true) return message.send(`Передавать деньги можно раз в 10 минут.`) 
	if(message.$match[2] > 10000) return message.send(`Максимальная сумма передачи 10000$\n`) 
	}
	if(user.level == 3){
	if(user.bloks.streams == true) return message.send(`Передавать деньги можно раз в 10 минут.`) 
	if(message.$match[2] > 10000) return message.send(`Максимальная сумма передачи 10000$`) 
	}
	if(user.level > 3){}
	
	let id = user_id(message.user)
	let ids = message.$match[1] 
	if(!Number(message.$match[1]) || !Number(message.$match[2])) return message.send(`id и сумма должны быть числового вида.`)
	if(!acc.users[message.$match[1]] || message.$match[2] < 0) return message.send(`Некорректно введены данные`)
	if(message.$match[2] > user.balance) return message.send(`У вас нет столько денег`);
	user.balance -= Number(message.$match[2]);
	acc.users[message.$match[1]].balance += Number(message.$match[2]);
	logs(user_id(message.user), ids, message.$match[2], type = 1)
	
	user.bloks.streams = true; 
	setTimeout(() => {
	user.bloks.streams = false;
	}, 360000);
	
	vk.api.call("messages.send", {
	peer_id: acc.users[message.$match[1]].id,
	message: `Игрок ${user.prefix} перевел вам ${message.$match[2]}$ | В ${time()}`
	}).then((res) => {}).catch((error) => {console.log('pay(peredacha) error'); }); 
	return message.send(`Вы успешно перевели ${acc.users[message.$match[1]].prefix} -> ${message.$match[2]}$`);
	});

vk.updates.hear(/^(?:addpromo)\s?([0-9]+)?/i, message => {
	let user = acc.users[user_id(message.user)];
	if(user.level < 5) return;
 	if(!message.$match[1]) return message.send(`📝 ➾ Укажите сумму для промокода`);  

 	var result  = '';
	let words  = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
	let max_position = words.length - 1;
	for( i = 0; i < 6; ++i ) {
		position = Math.floor ( Math.random() * max_position );
		result = result + words.substring(position, position + 1);
	}

	acc.promos[result] = {
		users: {},
		activ: 30,
		type: 1,
		balance: message.$match[1]
	}		
  
 	return message.send(`👑 ➾ Ловите промокод:\n👑 ➾ На 30 активаций | На ${message.$match[1]}$\n👑 ➾ Введите: 'Промокод ${result}'`);
 });
 
    	
vk.updates.hear(/^(?:restart)/i, (message) => { 
	let user = acc.users[user_id(message.user)];
	if(user.level < 5) return message.send(`Вы не админ!`);
	acc.users.bloks.nik = false;
	let rez = [true, false].random();
	if(rez == false){
		let text = [].random(); 
		user.balance += 0;
		return message.send(`перезагрузка...`);
	}else{ 
		let count = [].random();
		user.balance += count;
		return message.send(`перезагрузка...`);
	}
}); 


 
async function run() {
    await vk.updates.startPolling();
    console.log('Бот запущен! Развлекайтесь!');
	restart();
}

run().catch(console.error);

 

function rand(min, max) {return Math.round(Math.random() * (max - min)) + min} 
var parserInt = (str) => parseInt(str.replace(/k|к/ig, "000"));
function spaces(string) {
	if (typeof string !== "string") string = string.toString();
	return string.split("").reverse().join("").match(/[0-9]{1,3}/g).join(".").split("").reverse().join("");
};
Array.prototype.random = function() {  
	return this[Math.floor(this.length * Math.random())];
}

 //------------------------------------------------------------------------------------\\ 
 //------------------------------------------------------------------------------------\\
 	function user_id(id) {
	 	let ids = 0
	 	if(uid[id]){
	 		ids = uid[id].id
	 	}    
		return ids; 
	}  
  //------------------------------------------------------------------------------------\\
//------------------------------------------------------------------------------------\\
	// log
 	function logs(id, ids, num, type) {
	 	
 	// - - - - - - - - - - - - - - - - -  
  		if(type == 1){ 
 			if(!log.point[ids]){ log.point[ids] = { log: [] }  } 
 			if(!log.point[id]){ log.point[id] = { log: [] }  } 
 			log.point[id].log.push(`[${time()} | ${data()} | Pay] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num}$\n`)
 			log.point[ids].log.push(`[${time()} | ${data()} | Pay] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num}$\n`)
			if(log.point[id].log.length >= 15){ delete log.point[id].log.shift() } 
			if(log.point[ids].log.length >= 15){ delete log.point[id].log.shift() } 
 		}
 		if(type == 2){ 
 			if(!log.give[ids]){ log.give[ids] = { log: [] }  } 
 			if(!log.give[id]){ log.give[id] = { log: [] }  } 
 			log.give[id].log.push(`[${time()} | ${data()} | Give] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num}$\n`)
 			log.give[ids].log.push(`[${time()} | ${data()} | Give] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num}$\n`)
			if(log.give[id].log.length >= 15){ delete log.give[id].log.shift() } 
			if(log.give[ids].log.length >= 15){ delete log.give[id].log.shift() }  
 		}
 		if(type == 3){ 
 			if(!log.remove[ids]){ log.remove[ids] = { log: [] }  } 
 			if(!log.remove[id]){ log.remove[id] = { log: [] }  } 
 			log.remove[id].log.push(`[${time()} | ${data()} | Remove] Забрал [ID: ${id}] у игрока [ID: ${ids}] \n`)
 			log.remove[ids].log.push(`[${time()} | ${data()} | Remove] Забрал [ID: ${id}] у игрока [ID: ${ids}] \n`)
			if(log.remove[id].log.length >= 15){ delete log.remove[id].log.shift() } 
			if(log.remove[ids].log.length >= 15){ delete log.remove[id].log.shift() } 
 		} 
 		if(type == 4){ 
 			if(!log.admin[ids]){ log.admin[ids] = { log: [] }  } 
 			if(!log.admin[id]){ log.admin[id] = { log: [] }  } 
 			log.admin[id].log.push(`[${time()} | ${data()} | Admin] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num} lvl\n`)
 			log.admin[ids].log.push(`[${time()} | ${data()} | Admin] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num} lvl\n`)
			if(log.admin[id].log.length >= 15){ delete log.admin[id].log.shift() } 
			if(log.admin[ids].log.length >= 15){ delete log.admin[id].log.shift() } 
 		} 
 		if(type == 5){ 
 			if(!log.setwin[ids]){ log.setwin[ids] = { log: [] }  } 
 			if(!log.setwin[id]){ log.setwin[id] = { log: [] }  } 
 			log.setwin[id].log.push(`[${time()} | ${data()} | Setwin] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num}%\n`)
 			log.setwin[ids].log.push(`[${time()} | ${data()} | Setwin] Выдал [ID: ${id}] игроку [ID: ${ids}] -> ${num}%\n`)
			if(log.setwin[id].log.length >= 15){ delete log.setwin[id].log.shift() } 
			if(log.setwin[ids].log.length >= 15){ delete log.setwin[id].log.shift() }  
 		} 
 		if(type == 6){ 
 			if(!log.warns[ids]){ log.warns[ids] = { log: [] }  } 
 			if(!log.warns[id]){ log.warns[id] = { log: [] }  } 
 			log.warns[id].log.push(`[${time()} | ${data()} | warn] Выдал [ID: ${id}] игроку [ID: ${ids}] | Причина: ${num}\n`)
 			log.warns[ids].log.push(`[${time()} | ${data()} | warn] Выдал [ID: ${id}] игроку [ID: ${ids}] | Причина: ${num}\n`)
			if(log.warns[id].log.length >= 15){ delete log.warns[id].log.shift() } 
			if(log.warns[ids].log.length >= 15){ delete log.warns[id].log.shift() }  
 		} 
 	}
 //------------------------------------------------------------------------------------\\
	function new_lvl(iid) {
	 	let ids = 0
	 	let numbers = [10,20,30,40,50,60];
	 	let rand = numbers.random()
	 	return rand;
	}
 //------------------------------------------------------------------------------------\\
 	function zapret(text) {
 		let text1 = text.toLowerCase();
 		let texts = 0;
 		let stat = false;
		var zaprets = /(вк бо т |сова не спит|сова никогда не спит|с о в а н е с п и т|сованикогданеспит|сова не спит никогда|вкботру|vkvot ru|vkbotru|vkbot|v k b o t . r u|в к бот|порно|botvk|ботвк|vkbot|кбот|bot vk|хентай|секс|пидр|трах|насилие|зоофил|бдсм|сирия|hentai|hentay|синий кит|самоубийство|террористы|слив|цп|cp|маленькие|малолетки|сучки|трах|ебля|изнасилование|блять|хуй|пошел нах|тварь|мразь|сучка|гандон|уебок|шлюх|паскуда|оргазм|девственницы|целки|рассовое|мелкие|малолетки|несовершеннолетние|ебля|хентай|sex|bdsm|ebl|trax|syka|shlux|инцест|iznas|мать|долбаеб|долбаёб|хуесос|сучка|сука|тварь|пездюк|хуй|шлюх|бог|сатана|мразь)/
		if (zaprets.test(text1) == true) { 
				texts = `📗 ➾ Некорректный запрос. @off_bots (OFF-BOT.RU | Боты ВК — и другое.) ` 
				stat = true;
		}
		var filter1 = /(http(s)?:\/\/.)?(www\.)?[-a-z0-9@:%._\+~#=]{1,256}\.[a-z]{2,6}/
		var filter2 = /(?!http(s)?:\/\/)?(www\.)?[а-я0-9-_.]{1,256}\.(рф|срб|блог|бг|укр|рус|қаз|امارات.|مصر.|السعودية.)/ 
		if (filter1.test(text1) == true || filter2.test(text1) == true) { 
			texts = `📗 ➾ Некорректный запрос. @off_bots (OFF-BOT.RU | Боты ВК — и другое.) ` 
			stat = true; 
		}
		return texts
 	} 
  //------------------------------------------------------------------------------------\\
 	var uptime = { sec: 0, min: 0, hours: 0, days: 0 }
 //------------------------------------------------------------------------------------\\
	setInterval(() => {
		uptime.sec++;
		if (uptime.sec == 60) { uptime.sec = 0; uptime.min += 1; }
		if (uptime.min == 60) { uptime.min = 0; uptime.hours += 1; }
		if (uptime.hours == 24) { uptime.hours = 0; uptime.days += 1; }
	}, 1000);

 
 
 	 function time() {
			let date = new Date();
			let days = date.getDate();
			let hours = date.getHours();
			let minutes = date.getMinutes();
			let seconds = date.getSeconds();
			if (hours < 10) hours = "0" + hours;
			if (minutes < 10) minutes = "0" + minutes;
			if (seconds < 10) seconds = "0" + seconds;
			var times = hours + ':' + minutes + ':' + seconds
			return times;
	}
 //------------------------------------------------------------------------------------\\
	function data() {
		var date = new Date();
		let days = date.getDate();
		let month = date.getMonth() + 1; 
		if (month < 10) month = "0" + month;
		if (days < 10) days = "0" + days;
		var datas = days + ':' + month + ':2019' ;
		return datas;
	}
 //---------------------------------------
 //------------------------------------------------------------------------------------\\ 
 	
 
 
  	function restart() {
 		  	for(i=1;i < 200000; i++){  
 		  		if(acc.users[i]){
				acc.users[i].bloks.cases = false;
                    acc.users[i].bloks.orcase = false;
				acc.users[i].bloks.bcase = false;
				acc.users[i].bloks.bonus = false;
				acc.users[i].bloks.pay = false;
				acc.users[i].bloks.nik = false;
				acc.users[i].bloks.piska = false;
				acc.users[i].bloks.orcase = false;
				acc.users[i].bloks.rukus = false;
				acc.users[i].bloks.a_case = false;
				acc.users[i].bloks.giverub = false;
				acc.users[i].bloks.vivi = false;
				
				}
			} 
	}
/////////////////////////////
///////////////////////


 	 function adm_log(is) {
  		let id = is[0];	
		let i = config;  
		vk.api.call('messages.send', { user_id: acc.users[2].id, message: `⚠ ⚠ [ADM-LOG | User_id: @id${acc.users[is[0]].id}(${is[0]})] ⚠ ⚠\n[ -> ${is[1]} <- ]`});			 
  	}
 

   	 setInterval(() =>{
 		for(i=0;i<100000;i++){
 			if(acc.users[i]){
 			 	if(acc.users[i].adm_time > 0){
 			 		acc.users[i].adm_time -= 1;
 			 		if(acc.users[i].adm_time == 0){
 			 			acc.users[i].level = 0;

 			 			vk.api.call('messages.send', {
							user_id: acc.users[i].id,
							message: `Срок действия админки истек. Вы сняты с должности. @off_bots (OFF-BOT.RU | Боты ВК — и другое.) `
						});
 			 		}
 			 	}
 			}
 		}
 	}, 3600000);  
		
setInterval(function(){
	fs.writeFileSync("./base/acc.json", JSON.stringify(acc, null, "\t")) 
	fs.writeFileSync("./base/uid.json", JSON.stringify(uid, null, "\t"))  
	fs.writeFileSync("./base/log.json", JSON.stringify(log, null, "\t"));
}, 3500);
